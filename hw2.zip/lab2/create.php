<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<style type="text/css">
			.error {color:red;}
		</style>
		<title>PDO: Create a Record</title>
	</head>
	<body>
		<!-- Container Start -->
		<div class="container">
			<div class="pageHeader">
				<h1>Create New Contact</h1>
			</div>
			<?php

				#include database connection
				include"config/database.php";

				$ID = "";
				$idError = "";
				$isIDValid = false;

				$Name = "";
				$nameError = "";
				$isNameValid = false;

				$Email = "";
				$emailError = "";
				$isEmailValid = false;

				$Phone = "";
				$phoneError = "";
				$isPhoneValid = false;

				$Title = "";
				$titleError = "";
				$isAddValid = false;

				$Created_Date = "";
				$created_dateError = "";
				$isCreated_DateValid = false;

				$Modified_Date = "";
				$modified_dateError = "";
				$isModified_DateValid = false;				
				
			if($_POST)	

				{
					#Check if name is valid
					if (empty($_POST['name']))
					{
						$nameError = "Name is required";
						$isNameValid = false;
					}
					else
					{
						$Customer_Name = sanitize_input($_POST['name']);
						if (!preg_match("/^[a-zA-Z-' ]*$/",$Name))
						{
							$nameError = "Only letters and whitespace allowed";
							$isNameValid = false;
						}
						else
						{
							$isNameValid = true;
						}
					}

					#Check if email is valid
					if (empty($_POST['email']))
					{
						$emailError = "Email is required";
						$isEmailValid = false;
					}
					else
					{
						$Email = sanitize_input($_POST['email']);
						if (!preg_match("/^[a-zA-Z-' ]*$/", $Email))
						{
							$emailError = "Only letters and whitespace allowed";
							$isEmailValid = false;
						}
						else
						{
							$isEmailValid = true;
						}
					}

					#Check if contact phone number is valid
					if (empty($_POST['phone']))
					{
						$phoneError = "Contact phone number is required";
						$isPhoneValid = false;
					}
					else
					{
						$Phone = sanitize_input($_POST['phone']);
						if (!preg_match("/^[+]?[1-9][0-9]{9,14}$/", $Phone))
						{
							$phoneError = "Please enter a valid phone number";
							$isPhoneValid = false;
						}
						else
						{
							$isPhoneValid = true;
						}
					}

					#Check if title is valid
					if (empty($_POST['title']))
					{
						$titleError = "Title required";
						$isTitleValid = false;
					}
					else
					{
						$Add = sanitize_input($_POST['title']);
						if (!preg_match("/^[0-9a-zA-Z. ]+$/", $Title))
						{
							$titleError = "Please enter a valid title";
							$isTitleValid = false;
						}
						else
						{
							$isTitleValid = true;
						}
					}

					#Check if Created Date is valid
					if (empty($_POST['created_date']))
					{
						$created_dateError = "Created date required";
						$isCreated_DateValid = false;
					}
					else
					{
						$Created_Date = sanitize_input($_POST['created_date']);
						if (!preg_match("/^[a-zA-Z-' ]*$/", $Created_Date))
						{
							$created_dateError = "Only letters and whitespace allowed.";
							$isCreated_DateValid = false;
						}
						else
						{
							$isCreated_DateValid = true;
						}
					}

					#Check if modified date is valid
					if (empty($_POST['modified_date']))
					{
						$modified_dateError = "Modified date required.";
						$isModified_DateValid = false;
					}
					else
					{
						$Modified_Date = sanitize_input($_POST['modified_date']);
						#This validation will only apply to United States postal codes.
						if (!preg_match("/^\d{5}(?:\-\d{4})?$/i", $Modified_Date))
						{
							$modified_dateError = "Modified date required.";
							$isModified_DateValid = false;
						}
						else
						{
							$isModified_DateValid = true;
						}
					}
					

					if ($isNameValid && $isEmailValid && $isPhoneValid && $isTitleValid && $isCreated_DateValid && $isModified_DateValid)

						include "config/database.php";
					{
						try
						{
							#Insert Query
							$query= "INSERT INTO contacts SET Name=:name, Email=:email, Phone=:phone, Title=:title, Created_Date=:created_date, Modified_Date=:modified_date";

							#Prepare query for execution
							$stmt = $con -> prepare($query);

							$Name = htmlspecialchars(strip_tags($_POST['name']));
							$Email = htmlspecialchars(strip_tags($_POST['email']));
							$Phone = htmlspecialchars(strip_tags($_POST['phone']));
							$Title = htmlspecialchars(strip_tags($_POST['title']));
							$Created_Date = htmlspecialchars(strip_tags($_POST['created_date']));
							$Modified_Date = htmlspecialchars(strip_tags($_POST['modified_date']));						

							#Bind parameters
							$stmt -> bindParam(':name',$Name);
							$stmt -> bindParam(':email',$Email);
							$stmt -> bindParam(':phone',$Phone);
							$stmt -> bindParam(':title',$Title);
							$stmt -> bindParam(':created_date',$Created_Date);
							$stmt -> bindParam(':modified_date',$Modified_Date);							

							#Execute query

							if ($stmt -> execute())
							{
								Echo '<div class="alert alert-success" role="alert"> Entry Successful </div>';
							}
							else
							{
								echo '<div class="alert alert-warning" role="alert">Entry failed. Please verify data is correct and resubmit.</div>';
							}
						}
						catch(PDOException $e)
						{
							echo "Error".$e -> getMessage();
						}
					}
				}
				function sanitize_input ($data)
				{
					$data = trim($data);
					$data = stripslashes($data);
					$data = htmlspecialchars($data);
					return $data;
				}
			?>
			<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
				<table class="table table-hover table-responsive table-bordered">
					<tr>
						<td>Name</td>
						<td>
							<input type="text" name="name" class="form-control" value="<?php echo $Name ;?>">
							<span class="Error"><?php echo $nameError;?></span>
						</td>
					</tr>
					<tr>
						<td>Email</td>
						<td>
							<input type="text" name="email" class="form-control" value="<?php echo $Email ;?>">
							<span class="Error"><?php echo $emailError;?></span>
						</td>
					</tr>
					<tr>
						<td>Phone</td>
						<td>
							<input type="text" name="phone" class="form-control" value="<?php echo $Phone ;?>">
							<span class="Error"><?php echo $phoneError;?></span>
						</td>
					</tr>
					<tr>
						<td>Title</td>
						<td>
							<input type="text" name="title" class="form-control" value="<?php echo $Title ;?>">
							<span class="Error"><?php echo $titleError;?></span>
						</td>
					</tr>
					<tr>
						<td>Created Date</td>
						<td>
							<input type="text" name="created_date" class="form-control" value="<?php echo $Created_Date ;?>">
							<span class="Error"><?php echo $created_dateError;?></span>
						</td>
					</tr>
					<tr>
						<td>Modified Date</td>
						<td>
							<input type="text" name="modified_date" class="form-control" value="<?php echo $Modified_Date ;?>">
							<span class="Error"><?php echo $modified_dateError;?></span>
						</td>
					</tr>					
						<td></td>
						<td>
							<input type="submit" value="Submit" name="Submit" class="btn btn-success">		
							<a href="index.php" class="btn btn-primary">Home</a>
						</td>
					</tr>
				</table>
			</form>
		</div>
		<!-- Container End -->
	</body>
</html>


