<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<title>Edit Record</title>
	</head>
	<body>
		<!-- Container Start -->
		<div class="container">
			<div class="page-header">
				<h1>Edit Record</h1>
			</div>

			<?php

			$id=isset($_GET['id']) ?$_GET['id'] : die("ERROR: ID not found.");
			#echo $id; This was used to verify the code was working.

			#include database connection
			include"config/database.php";

			if($_POST)
			{
				try
				{
					#Create query to update the record
					$query= "UPDATE contacts SET Name=?, Email=?, Phone=?, Title=?, Created_Date=?, Modified_Date=? WHERE id=?";

					#Prepare query for execution
					$stmt = $con -> prepare($query);

					$name=sanitize_input($_POST['name']);
					$email=sanitize_input($_POST['email']);
					$phone=sanitize_input($_POST['phone']);
					$title=sanitize_input($_POST['title']);
					$created_date=sanitize_input($_POST['created_date']);
					$modified_date=sanitize_input($_POST['modified_date']);
					$id=sanitize_input($id);

					#Bind the parameters
					$stmt -> bindParam(1,$name);
					$stmt -> bindParam(2,$email);
					$stmt -> bindParam(3,$phone);
					$stmt -> bindParam(4,$title);
					$stmt -> bindParam(5,$created_date);
					$stmt -> bindParam(6,$modified_date);
					$stmt -> bindParam(7,$id);

					#Execute the query
					if($stmt -> execute())
					{
						echo "<div class='alert alert-success'>Record updated successfully</div>";
					}
					else
					{
						echo "<div class='alert alert-danger'>Unable to update the record. Please verify all information is correct then try again.</div>";
					}

				}
				catch(PDOException $ER)
				{
					echo "ERROR: ".$ER -> getMessage();
				}
			}

			try
			{
				#Prepare Select Query
				$query = "SELECT id, Name, Email, Phone, Title, Created_Date, Modified_Date From contacts WHERE id=? LIMIT 0,1";
				$stmt = $con -> prepare($query);

				#Binding
				$stmt -> bindParam(1,$id);

				#Execute
				$stmt -> execute();

				#Convert the PDO object to an array
				$row = $stmt -> fetch(PDO ::FETCH_ASSOC);

				#This was used to verify the code thus far works.
				#echo "<pre>";
				#print_r($row);
				#echo "</pre>";

				#Values to fill up
				$name = $row["Name"];
				$email = $row["Email"];
				$phone = $row["Phone"];
				$title = $row["Title"];
				$created_date = $row["Created_Date"];
				$modified_date = $row["Modified_Date"];

			}
			catch(PDOException $ER)
			{
				echo "ERROR: ".$ER -> getMessage(); 
			}

			#Sanitize the input data
			function sanitize_input ($data)
				{
					$data = trim($data);
					$data = stripslashes($data);
					$data = htmlspecialchars($data);
					return $data;
				}
			?>

			<form action="update.php?id=<?php echo htmlspecialchars($id); ?>" method="post">
				<table class="table table-hover table-responsive table-bordered">
					<tr>
						<td>Name</td>
						<td>
							<input type="text" name="name" class="form-control" value="<?php echo $Name ;?>">
						</td>
					</tr>
					<tr>
						<td>Email</td>
						<td>
							<input type="text" name="email" class="form-control" value="<?php echo $Email ;?>">
						</td>
					</tr>
					<tr>
						<td>Phone</td>
						<td>
							<input type="text" name="phone" class="form-control" value="<?php echo $Phone ;?>">
						</td>
					</tr>
					<tr>
						<td>Title</td>
						<td>
							<input type="text" name="title" class="form-control" value="<?php echo $Title ;?>">
						</td>
					</tr>
					<tr>
						<td>Created Date</td>
						<td>
							<input type="text" name="created_date" class="form-control" value="<?php echo $Created_Date ;?>">
						</td>
					</tr>
					<tr>
						<td>Modified Date</td>
						<td>
							<input type="text" name="modified_date" class="form-control" value="<?php echo $Modified_Date ;?>">
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="submit" class="btn btn-primary">
							<a href="index.php" class="btn btn-danger">Home</a>
						</td>
					</tr>
				</table>
			</form>
		</div>
		<!-- Container End -->
	</body>
</html>