<?php
$host = "mysql.patricksala.com";
$dbName = "contacts";
$userName = "patricksalacom";
$password = "sBpgyFMR";

try {
  $con = new PDO("mysql:host={$host};dbname={$dbName}",$userName,$password);
  //echo "Connection Good";
}

catch (Exception $e){
  echo "Connection Error:".$e->getMessage();
}
?>






























